
import sys
import os

from PySide6 import QtUiTools, QtGui, QtWidgets
from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import QApplication, QMainWindow, QTableWidgetItem
from PySide6.QtGui import QAction, QKeySequence,QKeySequence
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

import win32api
import tkinter.messagebox as msgbox
import schedule
import time
import threading
import pickle
import random
from pywinauto import application
import pygetwindow as gw
import calendar
from selenium.webdriver.common.alert import Alert
from win10toast import ToastNotifier as win10Toast
#from win11toast import ToastNotification as win11Toast
import platform
import mysql.connector
import clipboard



"""
pip install schedule
pip install Pyside6
pip install selenium
pip install pywin32      ## win32api
pip install win10toast
pip install win11toast
pip install mysql-connector-python
pip install clipboard
"""


server_setting={}
account_setting={}
account_info = ["acsId", "acsPw", "devPuttyId", "prodPuttyId", "devPuttyPw"
        , "prodPuttyPw", "adId", "adPw", "sdpId", "sdpPw","epId","epPw","dbId","dbPw"]
jira_search_condition={}
account_path = "autoAcsConfig.txt"
server_path = "serverConfig.txt"
# 파일 경로
# pyinstaller로 원파일로 압축할때 경로 필요함
def win_alert(options):
    if platform.release() == "10":
        # icon: 아이콘
        # duration: 알림 지속 시간 (초)
        # threaded: 알림 백그라운드 표시 여부 boolean
        # callback: 알림 클릭 시 실행할 함수
        toast=win10Toast()
        toast.show_toast(
            options["title"],
            options["content"],
            icon_path=None,
            duration=options["duration"],
            threaded=True
        )
    #elif platform.release() == "11":
        #https://pypi.org/project/win11toast/
        # icon: 아이콘
        # duration: 알림 지속 시간 (초)  duration = 'long' =25 초 scenario = 'incomingCall' no timeout
        # threaded: 알림 백그라운드 표시 여부 boolean
        # on_click : 알림 클릭 시 실행할 함수 혹은 파일 r 'C:\Users\Admin\Downloads\handler.pyw' )
        #win11Toast(options["content"], scenario = 'incomingCall')


def resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)


def setting_load():
    global server_setting
    global account_setting
    global account_info
    
    #서버 설정 기본 값
    server_info = {
        "devWebServer": "10.150.95.228"
        , "devWasServer": "10.150.95.229"
        , "prodWebServer1": "10.150.95.71"
        , "prodWebServer2": "10.150.95.91"
        , "gateWay": "10.150.133.119"
        , "prodWasServer1": "10.150.95.74"
        , "prodWasServer2": "10.150.95.94"
        , "devWebSsh": "ssh-an2-weeportal-dev-web-apaadm"
        , "devWasSsh": "ssh-an2-weeportal-dev-was-wasadm"
        , "prodWebSsh": "ssh-an2-weeportal-prd-web-apaadm"
        , "prodWasSsh": "ssh-an2-weeportal-prd-was-wasadm"
        , "webId": "apaadm"
        , "wasId": "wasadm"
    }
    # 계정설정 파일 경로
    global account_path
    global server_path
    setting_check_flag=False
    # 계정 세팅 정보 read
    if os.path.isfile(account_path):
        with open(account_path, "rb") as setFile:
            setdata = pickle.load(setFile)
        for k, v in setdata.items():
            account_setting[k] = v
    else:
        for a in account_info:
            account_setting[a] = ""

    # 서버 세팅 정보 read
    if os.path.isfile(server_path):
        with open(server_path, "rb") as setFile:
            setdata = pickle.load(setFile)
        for k, v in setdata.items():
            server_setting[k] = v
    else:
        for k, v in server_info.items():
            server_setting[k] = v
setting_load()
class MainView(QMainWindow):
    def __init__(self):
        super().__init__()
        self.lastNum = 1
        self.app = application.Application(backend='uia')
        self.jiraCheckUrl = "http://hlm.lge.com/issue/projects/WEEPPDEV/issues?filter=allopenissues&orderby=created+DESC%2C+priority+DESC%2C+updated+DESC"
        self.setupUI()
        self.mainMenuBar = self.menuBar()
        self.show()

    def setupUI(self):
        global UI_set
        # UI_set = QtUiTools.QUiLoader().load(resource_path("C:\Python311\Lib\site-packages\PySide6\WEEPP 운영 Tool main.ui"))
        UI_set = QtUiTools.QUiLoader().load(resource_path("./home.ui"))
        self.setCentralWidget(UI_set)
        menubar = self.menuBar()
        move_home_menu = QAction('Home', self)
        move_home_menu.setStatusTip("Move Home")
        move_home_menu.triggered.connect(lambda: self.pageChange('home'))
        move_home_menu.setShortcut('Ctrl+1')

        move_log_menu = QAction('Log',self)
        move_log_menu.setStatusTip("Move Log Page")
        move_log_menu.triggered.connect(lambda :self.pageChange('logPage'))
        move_log_menu.setShortcut('Ctrl+2')

        move_jira_menu = QAction('JIRA',self)
        move_jira_menu.setStatusTip("Move JIRA Page")
        move_jira_menu.triggered.connect(lambda :self.pageChange('jiraPage'))
        move_jira_menu.setShortcut('Ctrl+3')

        move_etc_menu = QAction('ETC', self)
        move_etc_menu.setStatusTip("ETC Setting Page")
        move_etc_menu.triggered.connect(lambda: self.pageChange("etcPage"))
        move_etc_menu.setShortcut("Ctrl+4")

        move_setting_menu = QAction('Setting',self)
        move_setting_menu.setStatusTip("Move Setting Page")
        move_setting_menu.triggered.connect(lambda: self.pageChange("settingPage"))
        move_setting_menu.setShortcut("Ctrl+5")

        file_menu=menubar.addMenu("File")
        file_menu.addAction(move_home_menu)
        file_menu.addAction(move_log_menu)
        file_menu.addAction(move_jira_menu)
        file_menu.addAction(move_etc_menu)
        file_menu.addAction(move_setting_menu)
        self.page_event_connect(UI_set, "home")
        self.setWindowTitle("WEE 통합 도구")
        self.setWindowIcon(QtGui.QPixmap(resource_path("./images/jbmpa.png")))
        self.setFixedSize(QSize(850, 550))
        self.show()

    def pageChange(self,page):
        ui_set = QtUiTools.QUiLoader().load(resource_path("./{0}.ui".format(page)))
        self.setCentralWidget(ui_set)
        self.page_event_connect(ui_set, page)


    def page_event_connect(self,ui_set,page):
        global account_setting
        global server_setting

        if page ==  "home":
            ui_set.logPageBtn.clicked.connect(lambda: self.pageChange("logPage"))
            ui_set.JiraPageBtn.clicked.connect(lambda: self.pageChange("jiraPage"))
            ui_set.etcPageBtn.clicked.connect(lambda: self.pageChange("etcPage"))
            ui_set.settingPageBtgn.clicked.connect(lambda: self.pageChange("settingPage"))
        elif page == "jiraPage":
            self.change_jira_box(ui_set)
            ui_set.debugChromeOpenBtn.clicked.connect(lambda: self.openDebbugChrome())
            ui_set.EnterEpCount.clicked.connect(lambda: self.enter_ep_account())
            ui_set.jiraCheckingBtn.clicked.connect(lambda: self.create_jira_thread(ui_set))
            ui_set.jiraCheckingStopBtn.clicked.connect(lambda: self.stop_jira_thread(ui_set))
            ui_set.jiraInfoGetBtn.clicked.connect(lambda: self.jira_info_search(ui_set))
            ui_set.sdpLoginBtn.clicked.connect(lambda: self.sdp_login())
            ui_set.sdpInsertBtn.clicked.connect(lambda: self.sdp_insert())
            ui_set.jiraSearchSelect.currentTextChanged.connect(lambda: self.change_jira_box(ui_set))
            if not hasattr(self,"jira_check_thread")  or (hasattr(self,"jira_check_thread") and not self.jira_check_thread.is_alive()):
                self.change_jira_btn(ui_set,True)
            else:
                self.change_jira_btn(ui_set, False)
        elif page == "logPage":
            ui_set.webviewerBtn.clicked.connect(lambda: self.webViewer_Login())
            #개발 서버
            ui_set.debAcsLoginBtn.clicked.connect(lambda: self.acs_login("DEV"))
            ui_set.devValutLoginBtn.clicked.connect(lambda: self.valult_login())
            ui_set.debWebLoginBtn.clicked.connect(lambda: self.insert_server_info(server_setting["devWebSsh"],server_setting["webId"],server_setting["devWebServer"]))
            ui_set.devWasLoginBtn.clicked.connect(lambda: self.insert_server_info(server_setting["devWasSsh"],server_setting["wasId"],server_setting["devWasServer"]))
            #운영 서버
            ui_set.prodAcsLoginBtn.clicked.connect(lambda: self.acs_login("PROD"))
            ui_set.prodValutLoginBtn.clicked.connect(lambda: self.valult_login())
            ui_set.prodWebLoginBtn_1.clicked.connect(lambda: self.insert_server_info(server_setting["prodWebSsh"], server_setting["webId"],server_setting["prodWebServer1"]))
            ui_set.prodWebLoginBtn_2.clicked.connect(lambda: self.insert_server_info(server_setting["prodWebSsh"], server_setting["webId"],server_setting["prodWebServer2"]))
            ui_set.prodWasLoginBtn_1.clicked.connect(lambda: self.insert_server_info(server_setting["prodWasSsh"], server_setting["wasId"],server_setting["prodWasServer1"]))
            ui_set.prodWasLoginBtn_2.clicked.connect(lambda: self.insert_server_info(server_setting["prodWasSsh"], server_setting["wasId"],server_setting["prodWasServer2"]))
                
        elif page == "settingPage":
            ui_set.accoutSettingPageBtgn.clicked.connect(lambda: self.pageChange("accountSettingPage"))
            ui_set.serverSettingPageBtgn.clicked.connect(lambda: self.pageChange("serverSettingPage"))
        elif page ==  "accountSettingPage":
            self.account_setting_load(ui_set)
            ui_set.accountSaveBtn.clicked.connect(lambda: self.save_account_setting(ui_set))
            ui_set.recommendPwBtn.clicked.connect(lambda: self.randomAcsPasswordRecommand(ui_set))
        elif page ==  "serverSettingPage":
            self.server_setting_load(ui_set)
            ui_set.serverSettingSaveBtn.clicked.connect(lambda :self.save_server_setting(ui_set))
        elif page ==  "etcPage":
            ui_set.sqlPageBtn.clicked.connect(lambda :self.pageChange("sqlPage"))
            ui_set.makeSpBtn.clicked.connect(lambda :self.make_spring_meg(ui_set))
        elif page ==  "sqlPage":
            ui_set.callSqlBtn.clicked.connect(lambda :self.call_sql(ui_set))

    def openDebbugChrome(self):
        #윈도우 명령어로 크롬 디벙깅 모드 실행
        win32api.WinExec('C:\Program Files\Google\Chrome\Application\chrome.exe --remote-debugging-port=9222 --user-data-dir="C:/ChromeTEMP"')
        self.connecting_Chrome()
        #self.driver.get('http://newep.lge.com/')

    def connecting_Chrome(self):
        # if (not hasattr(self, 'driver')):
        #     msgbox.showinfo("알림","Debug 크롬이 없습니다.")
        #     return
        chrome_options = Options()
        chrome_options.add_experimental_option('debuggerAddress', 'localhost:9222')
        self.driver = webdriver.Chrome(options=chrome_options)
        self.driver.implicitly_wait(10)

    def enter_ep_account(self):
        global account_setting
        self.connecting_Chrome()
        self.driver.get('http://newep.lge.com/')
        self.driver.find_element(By.ID, 'USER').send_keys(account_setting["epId"])
        self.driver.find_element(By.ID, 'LDAPPASSWORD').send_keys(account_setting["epPw"])
        # otp = input("OTP 입력 \n")
        # self.driver.find_element(By.ID, 'OTPPASSWORD').send_keys(otp)
        # self.driver.find_element(By.ID, 'loginSsobtn').click()


    def change_jira_btn(self,ui_set,flag):
        if flag:
            ui_set.jiraCheckLabel.setText("지라 체크")
            ui_set.jiraCheckingBtn.show()
            ui_set.jiraCheckingStopBtn.hide()
        else:
            ui_set.jiraCheckLabel.setText("지라 체크 중지")
            ui_set.jiraCheckingStopBtn.show()
            ui_set.jiraCheckingBtn.hide()
    def check_jira(self):
        self.connecting_Chrome()
        try:
            self.driver.get(self.jiraCheckUrl)
        except Exception as ex :
            self.enter_ep_account()
            msgbox.showinfo('에러','세션 혹은 크롬 연결이 끊겼습니다.')
            return
        print(datetime.now().strftime('%Y-%m-%d %H시 %M분 Checking...'))
        curNum = self.driver.find_element(By.ID, 'key-val').get_attribute('text').split('-')[1]
        if curNum > self.lastNum:
            print(datetime.now().strftime('%Y-%m-%d %H시 %M분 {}').format("신규 지라 감지"))
            win_alert({
                "title":"신규 지라 알림"
                ,"content":"신규 지라가 있습니다."
            })
            msgbox.showinfo('신규 지라 알림', '신규 지라가 있습니다.')
    def create_jira_thread(self,ui_set):
        if not hasattr(self,"jira_check_thread")  or (hasattr(self,"jira_check_thread") and not self.jira_check_thread.is_alive()):
            self.stop_event = threading.Event()
            self.jira_check_thread = threading.Thread(target=self.scheduling_jira)
            self.jira_check_thread.daemon=True
            self.jira_check_thread.start()
            self.change_jira_btn(ui_set, False)

    def scheduling_jira(self):
        if not hasattr(self, 'driver'):
            self.connecting_Chrome()
            if not hasattr(self, 'driver'):
                return
        print('start Jira Checking')
        self.driver.get(self.jiraCheckUrl)
        self.lastNum = self.driver.find_element(By.ID, 'key-val').get_attribute('text').split('-')[1]
        schedule.every(5).minutes.do(self.check_jira)

        while not self.stop_event.is_set():
            schedule.run_pending()
            time.sleep(1)
    def stop_jira_thread(self,ui_set):
        if hasattr(self, "jira_check_thread"):
            self.stop_event.set()
            self.change_jira_btn(ui_set, True)
    def account_setting_load(self,ui_set):
        global account_setting
        for k,v in account_setting.items():
            if hasattr(ui_set,k):
                ui_set.__getattribute__(k).setText(v)

    def server_setting_load(self,ui_set):
        global server_setting
        print(str(server_setting))
        for k, v in server_setting.items():
            if hasattr(ui_set, k):
                ui_set.__getattribute__(k).setText(v)
    #계정 설정 저장
    def save_account_setting(self,ui_set):
        global account_path
        global account_info
        writeData = {};
        for k in account_info:
            value = ui_set.__getattribute__(k).text().replace(" ", "");
            writeData[k] = value
            # if (value == ""):
            #     msgbox.showwarning("설정 입력 필요", "설정되지 않은 값이 있습니다.")
            #     return

        setFile = open(account_path, "wb")
        pickle.dump(writeData, setFile)
        setFile.close()
        for k, v in account_setting.items():
            account_setting[k] = writeData[k]
        msgbox.showinfo("설정 저장 완료", "설정이 저장되었습니다.")

    def save_server_setting(self,ui_set):
        global server_path
        global server_setting
        writeData = {};
        for k,v in server_setting.items():
            value = ui_set.__getattribute__(k).text().replace(" ", "");
            writeData[k] = value
            # if (value == ""):
            #     msgbox.showwarning("설정 입력 필요", "설정되지 않은 값이 있습니다.")
            #     return

        setFile = open(server_path, "wb")
        pickle.dump(writeData, setFile)
        setFile.close()
        for k, v in server_setting.items():
            server_setting[k] = writeData[k]
        msgbox.showinfo("설정 저장 완료", "설정이 저장되었습니다.")

    def randomAcsPasswordRecommand(self, ui_set):
        password = "!@"
        for i in range(0, 2):
            password += chr(random.randrange(65, 91))
        for i in range(0, 6):
            password += chr(random.randrange(97, 123))
        for i in range(0, 2):
            password += str(random.randrange(0, 10))
        ui_set.recommendPw.setText(password)



    # WebViewer 열기/선택
    def webViewer_select(self):
        win = gw.getWindowsWithTitle('Web Viewer Ver');
        if len(win) == 0:
            self.app.start("C://GateoneClient//WebViewer.exe")
            # try:
            #     time.sleep(1)
            #     if hasattr(self.app, 'Set Server URL'):
            #         dig = self.app['Set Server URL']
            #         dig.Edit.type_keys('acs.lge.com')
            #         dig['OK'].click()
            # except Exception as ex:
            #     print(ex)
            time.sleep(2)
        else:
            self.app.connect(path=r'C://GateoneClient//WebViewer.exe')

        win = gw.getWindowsWithTitle('Web Viewer Ver')[0]
        application.Application().connect(handle=win._hWnd).top_window().set_focus()
        win.activate()
        self._win = win

    #WebViewer 로그인
    def webViewer_Login(self):
        global account_setting
        if not hasattr(self,"_win"):
            self.webViewer_select()
        elif not (self._win.title == gw.getWindowsWithTitle('Web Viewer Ver')[0].title):
            self.webViewer_select()

        win = self._win
        application.Application().connect(handle=self._win._hWnd).top_window().set_focus()
        win.activate()
        dig =self.app[win.title]
        if dig['비밀번호Edit'].exists():
            dig.Edit.type_keys(account_setting["acsId"])
            dig['비밀번호Edit'].type_keys(account_setting["acsPw"])
            dig['로그인Hyperlink'].click_input()
        self._dig=dig

    def putty_connect(self):
        self.app.connect(path=r'C:\GateoneClient\Putty.exe')
        dig = self.app['acs.lge.com - PuTTY']
        self._dig = dig

    def acs_login(self, server):
        self.putty_connect()
        if server == "DEV":
            self._dig.type_keys('%s{ENTER}' % account_setting["devPuttyId"])
            self._dig.type_keys("%s{ENTER}" % account_setting["devPuttyPw"])
        elif server == "PROD":
            self._dig.type_keys('%s{ENTER}' % account_setting["prodPuttyId"])
            self._dig.type_keys("%s{ENTER}" % account_setting["prodPuttyPw"])

    def valult_login(self):
        self.putty_connect()
        dig = self.app[server_setting["gateWay"]]
        dig.type_keys("vault login -method=ldap -namespace=Wee_Portal username=%s{ENTER}" % account_setting["adId"], with_spaces=True)
        dig.type_keys("%s{ENTER}" % account_setting["adPw"])

    def insert_server_info(self, ssh, serverId, ip):
        self.putty_connect()
        dig = self.app[server_setting["gateWay"]]
        dig.type_keys("vault ssh -role %s -namespace=Wee_Portal -mode otp %s@%s{ENTER}" % (ssh, serverId, ip),with_spaces=True)
        dig.type_keys("atail{ENTER}")

    def change_jira_box(self,ui_set):
        select = ui_set.jiraSearchSelect.currentText()
        if select == "WEEPPDEV-N번 이후":
            ui_set.jiraSearchDate.hide()
            ui_set.jiraSearchNumber.show()
            ui_set.jiraSearchNumberLabel.show()
            ui_set.jiraSearchDateLabel.hide()
        elif select == "생성 년월":
            ui_set.jiraSearchDate.show()
            ui_set.jiraSearchDateLabel.show()
            ui_set.jiraSearchNumber.hide()
            ui_set.jiraSearchNumberLabel.hide()

    def jira_info_search(self,ui_set):
        global jira_search_condition
        select = ui_set.jiraSearchSelect.currentText()
        url=""
        if select == "WEEPPDEV-N번 이후":
            num = ui_set.jiraSearchNumber.text()
            url = "http://hlm.lge.com/issue/issues/?jql=project =" + " WEEPPDEV " + "AND key>WEEPPDEV-" + num + " AND  assignee in (" + account_setting["epId"] + ")"
        elif select ==  "생성 년월":
            year = int(ui_set.jiraSearchDate.text().split("-")[0])
            month = int(ui_set.jiraSearchDate.text().split("-")[1])
            date = datetime(year,month,1)
            from_day = "%d-%d-01" % (year,month)
            end_day = "%d-%d-%d" % (year,month, calendar.monthrange(date.year, date.month)[1])
            url = "http://hlm.lge.com/issue/issues/?jql=project =" + " WEEPPDEV " + "AND created >= " + from_day + " AND created <= " + end_day + " AND assignee in (" + account_setting["epId"] + ")"
        jira_search_condition['tYear']=int(ui_set.sdpTarget.text().split("-")[0])
        jira_search_condition['tMonth']=int(ui_set.sdpTarget.text().split("-")[1])
        self.connecting_Chrome()
        self.driver.get("http://hlm.lge.com/issue/projects/WEEPPDEV/issues/WEEPPDEV-32?filter=allissues")
        self.driver.get(url)
        div = self.driver.find_elements(By.CLASS_NAME, 'issuerow')
        imglist = self.driver.find_elements(By.CSS_SELECTOR, '.issue-link img')
        issueList = []
        for i in range(len(div)):
            r = div[i].text.split("\n")
            d = div[i].find_element(By.CSS_SELECTOR, '.created span').get_attribute('title')[8:10]
            issueList.append(
                {'no': r[0], 'title': r[1], 'type': imglist[i].get_attribute('alt'), 'day': d if d[0] != '0' else d[1]})
        jira_search_condition["result"]=issueList


    def sdp_login(self):
        global account_setting
        self.connecting_Chrome()
        self.driver.get("http://10.150.7.167:8090/login")
        time.sleep(1)
        self.driver.find_element(By.ID, 'username').send_keys(account_setting["sdpId"])
        self.driver.find_element(By.ID, 'password').send_keys(account_setting["sdpPw"])
        self.driver.find_element(By.CLASS_NAME, 'btn').click()

    def sdp_insert(self):
        global jira_search_condition
        self.driver.get("http://10.150.7.167:8090/" + 'work/%d/%d' % (jira_search_condition["tYear"], jira_search_condition["tMonth"]))

        try:
            alert = Alert(self.driver)
            alert.accept()
            alert.accept()
        except Exception as ex:
            pass
        time.sleep(1)
        prev = len(self.driver.find_elements(By.CSS_SELECTOR, '#areaData tr'))

        for i in range(len(jira_search_condition["result"])):
            self.driver.find_element(By.ID, 'btnSave').click()

        for i in range(prev, prev + len(jira_search_condition["result"])):
            roleName = "처리담당자"
            taskName = "제품별 기능 개발"
            if jira_search_condition["result"][i - prev]['type'] == 'Task':
                taskName = "정기/비정기 배포"
            elif jira_search_condition["result"][i - prev]['type'] == 'Request':
                taskName = "서비스 일반 현황 문의"
            a = self.driver.find_element(By.CSS_SELECTOR,'#areaData tr:nth-child(%d)' % (prev + len(jira_search_condition["result"]) - ((i - prev))))
            Select(a.find_element(By.NAME, 'category')).select_by_visible_text(taskName)
            a.find_element(By.NAME, 'taskName').send_keys(jira_search_condition["result"][i - prev]['title'])
            Select(a.find_element(By.NAME, 'role')).select_by_visible_text(roleName)
            a.find_element(By.NAME, 'requestNo').send_keys(jira_search_condition["result"][i - prev]['no'])
            a.find_element(By.NAME, jira_search_condition["result"][i - prev]['day']).send_keys(5)

    def call_sql(self,ui_set):
        table_name = ui_set.tbNmInput.text()
        if table_name =='':
            msgbox.showinfo('입력','테이블 명을 입력 해주세요')
            return
        global account_setting
        try:
            remote = mysql.connector.connect(
                host = "rds-an2-weeportal-dev-mysql.c3kroziivdeq.ap-northeast-2.rds.amazonaws.com",
                port = 3310,
                user = account_setting["dbId"],
                password = account_setting["dbPw"],
                database = "wpp"
            )
            cursor = remote.cursor(dictionary=True)
            sql = """
            with recursive sequance (seq) as  (
                select 1 
                union all 
                select seq +1 from sequance
                where seq <50
            )
            select 
                a.* 
                ,concat(',',a.column_name)  as column_name2
                ,if(a.data_type = 'datetime',concat('date_format(',a.column_name ,', ''%Y-%m-%d'') as ',a.column_name ) ,concat(',',a.column_name)) as select_name
                ,concat('#{',a.camel_column_name,
                    case 
                        when a.data_type = 'varchar' then ', jdbcType=VARCHAR}'
                        when a.data_type = 'int' or a.data_type = 'bigint' or a.data_type ='number'  then ', jdbcType=NUMERIC}'
                        when a.data_type = 'datetime' then ', jdbcType=DATE}'
                        when a.data_type = 'timestamp' then ', jdbcType=TIMESTAMP}'
                        else '}'
                    end
                ) as mybatis_input_default
                ,concat('<if test="',a.camel_column_name,'!= null and ',a.camel_column_name,' != '''' ">\n'
                    ,',',column_name,' = ',
                    concat('#{',a.camel_column_name,
                        case 
                            when a.data_type = 'varchar' then ', jdbcType=VARCHAR}'
                            when a.data_type = 'int' or a.data_type = 'bigint' or a.data_type ='number'  then ', jdbcType=NUMERIC}'
                            when a.data_type = 'datetime' then ', jdbcType=DATE}'
                            when a.data_type = 'timestamp' then ', jdbcType=TIMESTAMP}'
                            else '}'
                        end
                    ),'\n</if>'
                ) as mybatis_if
                ,concat(a.camel_column_name,' : { type : ',
                    case 
                        when a.data_type = 'varchar' then '"String" } ,'
                        when a.data_type = 'int' or a.data_type = 'bigint' or a.data_type ='number'  then '"number" } ,'
                        when a.data_type = 'datetime' then '"date" } ,'
                        when a.data_type = 'timestamp' then '"date" } ,'
                        else 'String'
                    end
                ) as kendo_field
                ,concat('{'
                    ,'\t field:"',a.camel_column_name,'" \n'
                    ,'\t,title : ',a.camel_column_name,'Lng \n'
                    ,'\t,width: dynamicCellWidth(widthMax,"',a.camel_column_name,'",',a.camel_column_name,'Lng) \n'
                    ,'}'
                )as kendo_column
            from ( 
                select 
                    a.order_num
                    ,a.column_name
                    ,a.data_type
                    ,a.max_len
                    ,seq
                    ,group_concat(
                        case 
                            when substr(a.column_name,seq-1,1) = '_' then upper(substr(a.column_name,seq,1))
                            else lower(substr(a.column_name,seq,1))
                        end	
                        order by seq separator ''
                ) as camel_column_name
                from (
                    select 
                        lower(c.column_name) as column_name
                        ,c.ordinal_position as order_num
                        ,c.data_type 
                        ,c.character_maximum_length as max_len
                    from information_schema.`COLUMNS` c 
                    where c.table_schema ='WPP' 
                    and c.table_name ='"""+table_name+"""'
                )a inner join sequance 
                on seq <= length (a.column_name)
                where substr(a.column_name,seq,1) != '_'
                group by a.order_num
                ,a.column_name
                ,a.data_type
            )a  
            
            """
            cursor.execute(sql)
            result = cursor.fetchall()
            remote.close()
            table = ui_set.sqlResultTable
            header =[]
            table.setRowCount(len(result))
            table.setColumnCount(len(result[0]))
            for i,data in enumerate(result):
                cnt =0;
                for k,v in data.items():
                    if i == 0:
                        header.append(k)
                    item = QTableWidgetItem(str(v))
                    table.setItem(i,cnt,item)
                    cnt+=1
            table.setHorizontalHeaderLabels(header)
        finally:
            remote.close()

    def keyPressEvent(self, event) -> None:
        super().keyPressEvent(event)
        tableName = "sqlResultTable"
        try:
            if event.key() == Qt.Key.Key_V and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):

                tableName = "sqlResultTable"
                if hasattr(self.centralWidget(),"msgResult"):
                    tableName = "msgResult"

                selection = self.centralWidget().__getattribute__(tableName).selectedIndexes()

                if selection:
                    row_anchor = selection[0].row()
                    column_anchor = selection[0].column()

                    # clipboard = QApplication.clipboard()
                    rows = clipboard.text().split('\n')

                    if self.centralWidget().__getattribute__(tableName).rowCount() < row_anchor + len(rows) - 1:
                        self.centralWidget().__getattribute__(tableName).setRowCount(row_anchor + len(rows) - 1)

                    for index_row, row in enumerate(rows):
                        values = row.split("\t")
                        for index_col, value in enumerate(values):
                            item = QtWidgets.QTableWidgetItem(value)  # Fix here
                            self.centralWidget().__getattribute__(tableName).setItem(row_anchor + index_row, column_anchor + index_col, item)

            if (event.key() == Qt.Key.Key_C or event.key() == Qt.Key.Key_X) \
                    and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                tableName = "sqlResultTable"
                if hasattr(self.centralWidget(), "msgResult"):
                    tableName = "msgResult"
                copied_cell = sorted(self.centralWidget().__getattribute__(tableName).selectedIndexes())
                copy_text = ""
                max_column = copied_cell[-1].column()

                for cell in copied_cell:
                    cell_item = self.centralWidget().__getattribute__(tableName).item(cell.row(), cell.column())
                    if cell_item:
                        copy_text += cell_item.text()
                        if event.key() == Qt.Key.Key_X:
                            cell_item.setText("")
                    else:
                        copy_text += ""

                    if cell.column() == max_column:
                        copy_text += "\n"
                    else:
                        copy_text += "\t"

                clipboard.copy(copy_text)

        except Exception as e:
            print(e)
            pass

    def make_spring_meg(self,ui_set):
        text = ui_set.msgInput.text()
        if text =="":
            return

        if text.find("=") <0:
            msgbox.showinfo("에러","형식이 올바르지 않습니다.")

        t1 = text[:text.find("=")]
        t2 = text[text.find("=")+1:]

        sp = '<spring:message code="'+t1+'"/>'
        lng = t1[t1.rfind(".")+1:]+"Lng"
        result ="const "+lng+ ' = "' +sp +'" //'+t2
        table = ui_set.msgResult
        table.setItem(0, 0, QTableWidgetItem(result))
        table.setItem(1, 0, QTableWidgetItem(sp))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main = MainView()
    main.show()
    sys.exit(app.exec())


